using UnityEngine;
using System.Collections;

public class MarbleControl : MonoBehaviour {

    public float movementSpeed = 6.0f;
	public float speedModifier = 1.0f;

	public float jumpPower = 300.0f;
	public float jumpModifier = 1.0f;
	private bool isGrounded = false;

	public delegate void GemCollectedHandler(Vector3 position);
	public static event GemCollectedHandler GemCollected;

	void Update () 
	{
		HandleMovement();
		HandleJumping();

	}

	private void HandleMovement()
	{
		float finalSpeed = movementSpeed * speedModifier;
		Vector3 movement = (Input.GetAxis("Horizontal") * -Vector3.left * finalSpeed) + (Input.GetAxis("Vertical") * Vector3.forward * finalSpeed);
		GetComponent<Rigidbody>().AddForce(movement, ForceMode.Force);
	}

	private void HandleJumping()
	{
		if(Input.GetKeyDown(KeyCode.Space) && isGrounded)
		{
			isGrounded = false;
			GetComponent<Rigidbody>().AddForce(Vector3.up * (jumpPower * jumpModifier));
		}
	}

    void OnTriggerEnter  (Collider other  ) 
	{
        if (other.tag == "Pickup")
        {
			Vector3 foundPosition = other.transform.position;
            MarbleGameManager.SP.FoundGem();
            Destroy(other.gameObject);
			GemCollected(foundPosition);
        } 
    }

	void OnCollisionEnter(Collision col)
	{
		CheckIfWeCanJump(col.gameObject.transform.position);

	}

	private void CheckIfWeCanJump(Vector3 hitPosition)
	{
		if(hitPosition.y - transform.position.y < -0.5)
		{
			isGrounded = true;
		}
	}
}
