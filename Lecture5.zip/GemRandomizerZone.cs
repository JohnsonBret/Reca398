﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GemRandomizerZone : MonoBehaviour {

	public Vector3[] gemPositions;
	public int numActiveGems;
	public int numTotalGemsInCollection;

	public GameObject gemObject;
	public float GemRespawnWaitTime = 1.0f;
	public string TagToDetect = "Pickup";
	private int numRemainingGems;

	//TODO should probably do a box cast based on the extends of the spawning game object

	void Start()
	{
		numRemainingGems = numTotalGemsInCollection;
		StartupActiveGemsDetection();

	}

	// Use this for initialization
	void OnEnable () 
	{
		MarbleControl.GemCollected += HandleGems;
	}

	void OnDisable()
	{
		MarbleControl.GemCollected -= HandleGems;
	}

	private void HandleGems(Vector3 foundPosition)
	{
		if(FoundGemARandomizedGem(foundPosition))
		{
			if(RandomizerHasGemsRemaining())
			{
				Invoke("SpawnReplacementGem", GemRespawnWaitTime);
			}	
		}
	}

	private bool FoundGemARandomizedGem(Vector3 foundAtPosition)
	{
		foreach(Vector3 gemPosition in gemPositions)
		{
			if(gemPosition == foundAtPosition)
			{
				return true;
			}
		}
		return false;
	}

	private bool RandomizerHasGemsRemaining()
	{
		return numRemainingGems > 0 ?  true :  false;
	}

	private Vector3 CheckValidSpot()
	{

		List<Vector3> validSpots = new List<Vector3>();
		
		foreach(Vector3 spawnPosition in gemPositions)
		{
			Collider[] collidersHit = Physics.OverlapBox(spawnPosition, new Vector3(0.4f, 0.4f, 0.4f));

			if(collidersHit.Length > 0)
			{
				for(int i = 0; i < collidersHit.Length; i++)
				{
					if(collidersHit[i].gameObject.tag == "Pickup")
					{
						break;
					}
				}
			}
			else
			{
				validSpots.Add(spawnPosition);
			}
		}

		if(validSpots.Count > 0)
		{
			foreach(Vector3 spot in validSpots)
			{
				//Debug.Log("Valid spot at: " + spot);
			}
			return validSpots[Random.Range(0, validSpots.Count -1)];
		}
			Debug.Log("This should never happen - No Valid spot found");
			return Vector3.zero;

	}
		
	private void SpawnReplacementGem()
	{
		Vector3 openSpot = CheckValidSpot();
		if(!SpotAtVectorZero(openSpot))
		{
			Instantiate(gemObject, openSpot, Quaternion.Euler(-90,0,0));
			numRemainingGems--;
		}

		SpawnGemsTillWeReachDesiredActiveNumber();
	}

	private void SpawnGemsTillWeReachDesiredActiveNumber()
	{
		if(NumberOfActiveGemsLessThanDesired() && RandomizerHasGemsRemaining())
		{
			SpawnReplacementGem();
		}
	}

	private bool SpotAtVectorZero(Vector3 checkOpenSpot)
	{
		return checkOpenSpot == Vector3.zero ? true : false;
	}

	private bool NumberOfActiveGemsLessThanDesired()
	{
		return DetectNumberOfGemsInPositions() < numActiveGems;
	}

	private int DetectNumberOfGemsInPositions()
	{
		int pickupsFound = 0;

		foreach(Vector3 gemSpot in gemPositions)
		{
			Collider[] collidersHit = Physics.OverlapBox(gemSpot, new Vector3(0.4f, 0.4f, 0.4f));

			if(collidersHit.Length == 0)
			{
				continue;
			}
			else
			{
				foreach(Collider col in collidersHit)
				{
					if(col.gameObject.tag == TagToDetect)
					{
						pickupsFound++;
					}
				}
			}

		}
		return pickupsFound;
	}

	private void StartupActiveGemsDetection()
	{
		int pickupsFound = DetectNumberOfGemsInPositions();
		int pickupsExpected = numActiveGems;

		RemoveFoundPickupsFromRemainingGems(pickupsFound);
		MarbleGameManager.SP.AddRandomizerGems(numRemainingGems);

		if(pickupsFound == pickupsExpected)
		{
			return;
		}
		else
		{
			SpawnGemsTillWeReachDesiredActiveNumber();
		}
	}

	private void RemoveFoundPickupsFromRemainingGems(int foundPickups)
	{
		numRemainingGems -= foundPickups;
	}

	private void TroubleCheck()
	{
		if(numActiveGems == 0)
		{
			Debug.Log(gameObject.name + " Gem Randomizer - Number of Active Gems can't be Zero!");
		}

		if(numRemainingGems == 0)
		{
			Debug.Log(gameObject.name + " Gem Randomizer - Number of Remaining Gems can't be Zero!");
		}

		if(numTotalGemsInCollection == 0)
		{
			Debug.Log(gameObject.name + " Gem Randomizer - Total number of Gems can't be Zero!");
		}

		foreach(Vector3 position in gemPositions)
		{
			if(position.Equals(Vector3.zero))
			{
				Debug.Log("You have Gem Position at " + Vector3.zero + " Did you forget to set your gem position? Please don't use " + Vector3.zero + "It breaks the randomizer");	
			}
		}
	}
}
