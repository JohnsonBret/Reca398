using UnityEngine;
using System.Collections;

public class Playermovement : MonoBehaviour
{
    public float movementSpeed = 5.0f;
    private bool isGrounded = false;

    void Update() {
        GetComponent<Rigidbody>().velocity = new Vector3(0, GetComponent<Rigidbody>().velocity.y, 0); //Set X and Z velocity to 0
 
        transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * movementSpeed, 0, 0);

        /*if (Input.GetButtonDown("Jump") && isGrounded)
        {
            Jump(); //Manual jumping
        }*/
	}

    void Jump()
    {
        if (!isGrounded) { return; }
        isGrounded = false;
        GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        GetComponent<Rigidbody>().AddForce(new Vector3(0, 700, 0), ForceMode.Force);

		CheckAboveClear();
    }

	//Is there a big clear space above TopHat to jump?
	private void CheckAboveClear()
	{
		//Shoot an invisible Ray to gather information about what is above TopHat
		RaycastHit hitInformation;
		bool isPlatformThere = Physics.Raycast(transform.position, Vector3.up, out hitInformation, 9.5f);

		//If the platform is there lets do some stuff
		if(isPlatformThere)
		{
			//Debug.Log("Platform Distance: " + hitInformation.distance);
			float distanceToPlatform = hitInformation.distance;
			float bigJumpSoundCutOffDistance = 4.5f;

			if(distanceToPlatform > bigJumpSoundCutOffDistance)
			{
				//Big Jump Sound
			}
			else
			{
				//Small Jump Sound = I'm likely to hit my head
			}
		}
	}

    void FixedUpdate()
    {
        isGrounded = Physics.Raycast(transform.position, -Vector3.up, 1.0f);
        if (isGrounded)
        {
            Jump(); //Automatic jumping
        }
    }

	void OnCollisionEnter(Collision other)
	{
		Vector2 ImpactDirection = (Vector2)(other.transform.position - transform.position);
		float ImpactPower = other.impulse.magnitude;


		if(ImpactDirection.y > 0.8f)
		{
			if(ImpactPower > 8.0f)
			{
				//Debug.Log("Big Hit");
			}
			else if(ImpactPower > 4.0f && ImpactPower < 8.0f)
			{
				//Debug.Log("Medium Hit");
			} 
			else 
			{
				//Debug.Log("Small Hit");
			}
		}
		//Debug.Log("Impact Power: " + ImpactPower);
	}
       

}
