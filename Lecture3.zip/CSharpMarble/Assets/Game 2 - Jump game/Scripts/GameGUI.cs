using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class GameGUI : MonoBehaviour {

    public static GameGUI SP;
    public static int score;

	public Text displayScore;
	public Text displayHighScore;

	public GameObject panelGameOver;
	public GameObject newHighScoreText;

    private int bestScore = 0;

    void Awake()
    {
        SP = this;
        score = 0;
        bestScore = PlayerPrefs.GetInt("BestScorePlatforms", 0);
    }

	void Update()
	{
		displayScore.text = score.ToString();
		displayHighScore.text = bestScore.ToString();
	}

    void OnGUI()
    {
        //GUILayout.Space(3);
        //GUILayout.Label(" Score: " + score);
        //GUILayout.Label(" Highscore: " + bestScore);

        if (GameControl.gameState == GameState.gameover)
        {
			panelGameOver.SetActive(true);

            if (score > bestScore)
            {
				newHighScoreText.SetActive(true);
            }
			else
			{
				newHighScoreText.SetActive(false);
			}
        }
    }

    public void CheckHighscore()
    {
        if (score > bestScore)
        {
            PlayerPrefs.SetInt("BestScorePlatforms", score);
			bestScore = score;
        }
    }

	public void OnTryAgainPressed()
	{
		Application.LoadLevel(Application.loadedLevel);
		panelGameOver.SetActive(false);
	}

	public void OnResetHighScore()
	{
		PlayerPrefs.SetInt("BestScorePlatforms", 0);
		displayHighScore.text = "0";
		displayScore.text = "0";
		bestScore = 0;
		score = 0;
	}
}
