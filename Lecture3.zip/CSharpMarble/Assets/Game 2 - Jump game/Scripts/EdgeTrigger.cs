using UnityEngine;
using System.Collections;

public class EdgeTrigger : MonoBehaviour {

    //You could implement this yourself..

   void OnTriggerEnter(){
       Debug.Log("OnTriggerEnter..");
   }

}
