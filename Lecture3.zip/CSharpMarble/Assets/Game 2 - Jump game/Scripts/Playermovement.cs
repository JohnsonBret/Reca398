using UnityEngine;
using System.Collections;

public class Playermovement : MonoBehaviour
{
    public float movementSpeed = 5.0f;
    private bool isGrounded = false;
	public float jumpPower = 1000.0f;


    void Update() {
        GetComponent<Rigidbody>().velocity = new Vector3(0, GetComponent<Rigidbody>().velocity.y, 0); //Set X and Z velocity to 0
 
        transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * movementSpeed, 0, 0);

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            Jump(); //Manual jumping
        }
	}

    void Jump()
    {
        if (!isGrounded) { return; }
        isGrounded = false;
        GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
		GetComponent<Rigidbody>().AddForce(new Vector3(0, jumpPower, 0), ForceMode.Force);

		CheckAboveClear();
    }

	//Is there a big clear space above TopHat to jump?
	private void CheckAboveClear()
	{
		//Shoot an invisible Ray to gather information about what is above TopHat
		RaycastHit hitInformation;
		bool isPlatformThere = Physics.Raycast(transform.position, Vector3.up, out hitInformation, 9.5f);

		//If the platform is there lets do some stuff
		if(isPlatformThere)
		{
			//Debug.Log("Platform Distance: " + hitInformation.distance);
			float distanceToPlatform = hitInformation.distance;
			float bigJumpSoundCutOffDistance = 4.5f;

			if(distanceToPlatform > bigJumpSoundCutOffDistance)
			{
				//Big Jump Sound
			}
			else
			{
				//Small Jump Sound = I'm likely to hit my head
			}
		}
	}

    void FixedUpdate()
    {
        isGrounded = Physics.Raycast(transform.position, -Vector3.up, 1.0f);
        if (isGrounded)
        {
            Jump(); //Automatic jumping
        }
    }

	void OnCollisionEnter(Collision other)
	{
		Vector2 ImpactDirection = (Vector2)(other.transform.position - transform.position);
		float ImpactPower = other.impulse.magnitude;

		//Debug.Log("Impact Direction: " + ImpactDirection );

		//Head Smash
		if(ImpactDirection.y > 0.8f)
		{
			
		}

		if(Mathf.Abs(ImpactDirection.y) < 0.3f )
		{
			if(Mathf.Abs(ImpactDirection.x) > 0.2f)
			{
				//Debug.Log("Expected Side Hit");

			}
		}


	}
       

}
