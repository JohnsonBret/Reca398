using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class EggCollider : MonoBehaviour {

    PlayerScript myPlayerScript;


	//Wampus Stuff - You can Ignore this!
	public RectTransform wampusTransform;
	public Animator wampusAnimation;
	public GameObject wampusObject;

    //Automatically run when a scene starts
    void Awake()
    {
        myPlayerScript = transform.parent.GetComponent<PlayerScript>();
    }

    //Triggered by Unity's Physics
	void OnTriggerEnter(Collider theCollision)
    {

		if(theCollision.gameObject.tag == "PurpleWampus")
		{
			myPlayerScript.theScore += 25;
			handleTheWampus();
		}
		else
		{
			myPlayerScript.theScore++;
		}

        GameObject collisionGO = theCollision.gameObject;
        Destroy(collisionGO);
    }

	//Handles text for when you catch the Wampus
	private void handleTheWampus()
	{
		wampusObject.SetActive(true);
		//Debug.Log("Wampus point " + Camera.main.WorldToScreenPoint(transform.parent.position));
		Vector2 wampusPosition = (Vector2)Camera.main.WorldToScreenPoint(transform.parent.position) + new Vector2(0.0f, 100.0f);
		wampusTransform.anchoredPosition = wampusPosition;
		wampusAnimation.Play("TextAnimation");
	}
}
