using UnityEngine;
using System.Collections;

public class GameoverTrigger : MonoBehaviour {

	void OnTriggerEnter(Collider col)
    {
        
		if(col.gameObject.CompareTag("Player"))
		{
			MarbleGameManager.SP.SetGameOver();
		}
    }
}
