﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour {

	public Vector3 PositionOne;
	public Vector3 PositionTwo;

	public float SpeedPositionOne;
	public float SpeedPositionTwo;

	private Vector3 currentDestination;
	private float currentSpeedModifier;

	private float minimumDistance = 0.1f;


	void Awake () 
	{
		currentDestination = PositionOne;
		currentSpeedModifier = SpeedPositionOne;
	}
	

	void Update () 
	{

		if(Vector3.Distance(transform.position, currentDestination) <= minimumDistance)
		{
			SwitchDestination();
			return;
		}

		float stepDistance = Time.deltaTime * currentSpeedModifier;
		transform.position = Vector3.MoveTowards(transform.position, currentDestination, stepDistance);

		TroubleCheck();
	}

	private void SwitchDestination()
	{

		if(currentDestination == PositionOne)
		{
			currentDestination = PositionTwo;
			currentSpeedModifier = SpeedPositionTwo;
		}
		else
		{
			currentDestination = PositionOne;
			currentSpeedModifier = SpeedPositionOne;
		}
	}

	//Print to the console if we are using this class incorrectly
	private void TroubleCheck()
	{
		if(SpeedPositionOne  <= 0.0f || SpeedPositionTwo <= 0.0f)
		{
			Debug.Log("Moving Platform - Speed is less than or Zero - Your platform shouldn't be moving");
		}

		if(Vector3.Distance(PositionOne, PositionTwo) < minimumDistance)
		{
			Debug.Log("Moving Platform - Your two positions aren't far enough apart must be greater than " + minimumDistance);
		}

		if(PositionOne.Equals(Vector3.zero) && PositionTwo.Equals(Vector3.zero))
		{
			Debug.Log("Moving Platform - Your positions are both set to zero - Your platform has nowhere to go");
		}

		if(transform.parent != null)
		{
			Debug.Log("Moving Platform - I have a parent! I CANNOT child object");
		}
	}
}
