﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSCamera : MonoBehaviour {

	public Transform marble;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		float horizontal = Input.GetAxisRaw("Horizontal");
		float vertical = Input.GetAxisRaw("Vertical");

		//facing towards positive Z is 00
		Vector3 inputVector = new Vector3(horizontal, 0 , vertical);
		transform.position = marble.position;
		transform.LookAt(transform.position + inputVector);
		
	}
}
