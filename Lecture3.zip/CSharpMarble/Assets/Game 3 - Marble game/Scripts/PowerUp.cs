﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour {

	public PowerUpType powerUpType;
	public enum PowerUpType {SPEED, TIME, GAMEMODE}
	//power up for a fixed duration or permanent
	public float speedModifier = 1.0f;
	public float timeModifier = 0.0f;
	public MarbleGameManager.GameType changeGameType;

	void Awake () 
	{
		
	}
	

	void Update ()
	{
		
	}

	void OnTriggerEnter(Collider col)
	{
		if(col.gameObject.CompareTag("Player"))
		{
			if(powerUpType == PowerUpType.SPEED)
			{
				col.gameObject.GetComponent<MarbleControl>().speedModifier = speedModifier;
			}
			else if(powerUpType == PowerUpType.TIME)
			{
				MarbleGameManager.SP.AddTime(timeModifier);
			}
			else if(powerUpType == PowerUpType.GAMEMODE)
			{
				MarbleGameManager.SP.gameType = changeGameType;
			}


			gameObject.SetActive(false);
		}
	}
}
