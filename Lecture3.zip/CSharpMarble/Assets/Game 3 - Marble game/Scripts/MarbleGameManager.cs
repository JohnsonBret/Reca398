using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public enum MarbleGameState {playing, won,lost };

public class MarbleGameManager : MonoBehaviour
{
    public static MarbleGameManager SP;
	public GameType gameType;
	public float TimeLimit;

	public Text scoreText;
	public Text timeText;
	public GameObject panelWin;
	public GameObject panelLose;
	public GameObject panelGameTime;

    private int totalGems;
    private int foundGems;
    private MarbleGameState gameState;

	private float currentTime;

	public enum GameType {FREEPLAY, TIMED}

    void Awake()
    {
        SP = this; 
        foundGems = 0;
        gameState = MarbleGameState.playing;
        totalGems = GameObject.FindGameObjectsWithTag("Pickup").Length;
        Time.timeScale = 1.0f;

		//Reset UI result panels
		panelWin.SetActive(false);
		panelLose.SetActive(false);

		if(gameType == GameType.TIMED)
		{
			panelGameTime.SetActive(true);
			currentTime = TimeLimit;
		}
		else
		{
			panelGameTime.SetActive(false);
		}

    }

	void Update()
	{
		scoreText.text = "Gems Collected: " + foundGems + "/" + totalGems;

		//Handle Remaining time for a timed game
		if(gameType == GameType.TIMED)
		{
			//Lower the amount of time remaining
			currentTime -= Time.deltaTime;
			timeText.text = "Time: " + Mathf.RoundToInt(currentTime);

			//Have you run out of time without winning the game?
			if(currentTime <= 0  && gameState != MarbleGameState.won)
			{
				SetGameOver();
			}
		}
	}

    public void FoundGem()
    {
        foundGems++;
        if (foundGems >= totalGems)
        {
            WonGame();
        }
    }

    public void WonGame()
    {
        Time.timeScale = 0.0f; //Pause game
        gameState = MarbleGameState.won;

		//Make visible the UI for winners
		panelWin.SetActive(true);
    }

    public void SetGameOver()
    {
        Time.timeScale = 0.0f; //Pause game
        gameState = MarbleGameState.lost;

		//Make visible the UI for losers
		panelLose.SetActive(true);
    }

	public void RestartLevel()
	{
		//Restart whatever level is currently loaded
		SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
	}

	public void AddTime(float value)
	{
		currentTime += value;
	}
}
